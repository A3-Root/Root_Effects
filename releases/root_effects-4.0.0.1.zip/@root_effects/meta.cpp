name = "Root's Effects";
author = "Root";
overview = "Effects Zeus Addon based on 3DEN showcase by Aliascartoons. Imported, modified, maintained and published for Zeus Curator by Root.";

timestamp = 639279939740000000;
